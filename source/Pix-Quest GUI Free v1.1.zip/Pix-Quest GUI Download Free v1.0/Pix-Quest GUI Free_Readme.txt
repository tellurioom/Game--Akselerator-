Hi, Thanks for downloading Pix-Quest GUI free version! This outlines what is included in the free version:

- 2 unique color options for customizable buttons (with one button highlight color)
- Miscellaneous other buttons from full asset pack
- Status Bar Hearts v1 and round status bars (red & blue) in both horizontal and vertical format
- 2 unique color options for customizable menus (menu style 1 only), and fitting highlight options
- 1 cursor with click animation. 

Thank you again and I hope you enjoy this free version!

-Pixelsnorf